# 2. Pide un número al usuario. Di si es positivo, negativo o si es cero.

num = int(input("Ingresa numero: ")) # Ingresar datos por pantalla

if num >= 0: # condicinal 
    print("Es positivo")
else:
    print("Es negativo")