# 1. Pide al usuario su edad. Si tiene 18 años o más, imprime "Eres mayor de edad". Si no, imprime "Eres menor de edad".

edad = int(input("Ingresa tu  edad: ")) # Pedir valor de edad por pantalla. 

if edad >= 18:    #Condiconal si el valor ingresado cumple con la edad solicitada.
    print("Eres mayor de edad")
else: 
    print("Eres menor de edad") 