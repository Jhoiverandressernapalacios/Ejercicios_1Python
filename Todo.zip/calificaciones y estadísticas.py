notas = (input("Ingresar las calificaciones numérica (de 0 a 100): ")).split(sep=",") #imgresar datos por pantalla

suma_nota = 0 # variabble
calificaciones = [] # lista para guardar datos ingresados por pantalla


for nota in notas: # ciclo for para cada dato ingresado por pantalla se convierta en float y se almacene en la lista.
    nota = float(nota)
    calificaciones.append(nota)
    suma_nota += nota
promedio = (suma_nota/len(calificaciones)) # Imprimir promedios de la suma de los datos que estan en la lista y sacar promedio.
print("------------------------------------------------------------------------------------------------")# seperador para la hora de imprimir tenga mas estetica la impresion 
0 <= promedio <= 100 # variable promedio con rango limitado de 0 a 100.


if 0 <= promedio <= 4.9:# condicional if si la calificacion esta en un rango de 0 a  4.9 seria reprobado.
    print(f"La calificaciones ingresadas son: {calificaciones}")
    print(f"La suma total de las calificaciones ingresadas es: {suma_nota}")
    print(f"El promedio de de la calificaciones es: {promedio:.2f}") # Total de promedio imprimido por pantalla.
    print(f"Segun el promedio obtenido es: {promedio:2f} y la calificacion es reprobado")
   
else:
    if 5.0 <= promedio <=100:# condicional if si la calificacion esta en un rango de 4.9 a  100 seria aprobado.
        print(f"La calificaciones ingresadas son: {calificaciones}")
        print(f"La suma total de las calificaciones ingresadas es: {suma_nota}")
        print(f"El promedio de de la calificaciones es: {promedio:.2f}")# Total de promedio imprimido por pantalla.
        print(f"Segun el promedio obtenido es: {promedio:.2f} y la calificacion es aprobado")

print("------------------------------------------------------------------------------------------------")# seperador para la hora de imprimir tenga mas estetica la impresion 


valor = float(input("Ingresa valor en especifico: "))# Buscar calificacion mayor al valor específico.
conta = 0
i = 0
while i < len(calificaciones):# ciclo while para determinar en la lista ingresada por pantalla que calificion es mayor que la que se ingreso por valor.
    if calificaciones[i] > valor:
        conta += 1
    i += 1

print(f"El numero de calificaciones mayores que: {valor} en la lista son:{conta}") 

print("------------------------------------------------------------------------------------------------")# seperador para la hora de imprimir tenga mas estetica la impresion 

valor = float(input("Ingresa calificación específica para buscar : "))# ingresar valor por pantalla.
conta = 0
i = 0

while i < len(calificaciones):
    if calificaciones[i] < 0:  # Si encuentra una nota inválida
        i += 1
        continue  # Saltamos esta iteración
    
    if calificaciones[i] == valor: #si existe al menos una semejante 
        conta += 1
        
    
    if calificaciones[i] > 100:  
        print("Se encontró una calificación ")
        break  # se rompe el ciclo.
        
    i += 1

print(f"La calificación {valor} aparece {conta} veces en la lista ")
