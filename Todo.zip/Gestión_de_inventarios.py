# Diccionario con productos a consultar
inventario = {
    "001":{"producto":"Tablet", "precio": 1500000,"cantidad_dispo": 80 },
    "002":{"producto":"Dron", "precio": 3000000,"cantidad_dispo": 50 },
    "003":{"producto":"Portatil", "precio": 4500000,"cantidad_dispo": 30 },
    "004":{"producto":"impresora", "precio": 1800000,"cantidad_dispo": 79 },
    "005":{"producto":"Bocina JBL","precio": 3000000,"cantidad_dispo": 100 }

} 

# Muestra el menú de opciones
def Menu():
    print("\n MENU")
    print("---------------------------------------------------------------------------") 
    print("1. Añadir")
    print("2. Buscar")
    print("3. Actualizar")
    print("4. Eliminar productos")
    print("5. Valor total del inventario")
    print("6.Salir")


# Función para añadir un nuevo producto
def nuevo_produc():

    codigo = input("Ingrese un código único para el nuevo producto: ")
    nombre = input("Ingrese el nombre del producto: ")
    precio = input("Ingrese el precio del producto: ")
    cantidad = input("Ingrese la cantidad del producto: ")

 # Nuevo diccionario con los datos del producto que es nuevo
    new_produc = codigo = {
        'producto': nombre,
        'precio': int(precio),
        'cantidad': int(cantidad)
        }
    
    inventario.update(new_produc)   # Se actualiza el diccionario con el nuevo producto
    print(f"El producto: {new_produc} fue añadido al inventario.")

# Función para consultar un producto existente
def consultar_productos():
    productos =(input("Ingresa codigo producto a consultar: "))

    if productos in inventario:
        print (f"el producto que seleccionaste es: [{inventario[productos]}]")
    else:
        print(f" El producto {productos}, no se encuemtra en el inventario")
    


# Función para actualizar el precio de un producto en el diccionario
def actualizar_precios():
    valor = input("Ingresa el codigo del producto que quieres actualizar el precio: ")
    
    if valor in inventario:
        precio_actu = input(f"Ingresa el nuevo precio que le quieres actualizar al producto {inventario[valor]['producto']} es:")
        
        try:
            # Verificion que precio sea un número válido y positivo
            if float(precio_actu) < 0:
                print("No se permiten letras")

                return
            
            # Se actualiza el precio
            precio_final = precio_actu
            inventario[valor]["precio"]= precio_final
            print(f"El precio del producto: {inventario[valor]['producto']} se ha actualizado al valor de:{precio_actu}.")
            print(f"producto {inventario[valor]['producto']} actualizado con el nuevo precio: [{inventario[valor]}]")
        except ValueError:
            print("El precio ingresado es invalido")       
    
    else:
        print(f"El codigo {valor}, es invalido")


# Función para eliminar un producto del diccionario
def eliminar_productos():
    eliminar = input("Ingrese el codigo del producto que quieres eliminar: ").strip().lower()
    
    if eliminar in inventario:
        confirmacion = input(f"¿Está seguro que desea eliminar {inventario[eliminar]['producto']} del inventario? (si/no): ").strip().lower()
        if confirmacion == 'si':
            del inventario[eliminar]
            print(f"El producto {inventario[eliminar]['producto']} ha sido eliminado del inventario.")
            print(f"{inventario}")
        else:
            print("Operación cancelada.")
    else:
        print(f"El producto '{eliminar}' no se encuentra en el inventario.")
       


# Función calcular el valor total del diccionario.

def valortotal_del_inventario():
     while True:
         calcular_valor = lambda producto: sum(float(i['precio'])*int(i['cantidad_dispo']) for i in inventario.values())
         total =calcular_valor(inventario)
         print(f"Valor total del inventario: ${total:,.2f}")
         break



# Bucle principal del programa para elegir opcion
while True:
    Menu()
    opcion = input("Seleccione una opción del Menu: ")
    if opcion == '1':
        nuevo_produc()
    elif opcion == '2':
        consultar_productos()
    elif opcion == '3':
        actualizar_precios()
    elif opcion == "4":
        eliminar_productos()
    elif opcion == '5':
        valortotal_del_inventario()
    elif opcion == '6':
        print("Salida del inventario.")
        break
    else:
            print(f"Opción {opcion}, no esta en el Menu, Por favor, intente de nuevo.")
    